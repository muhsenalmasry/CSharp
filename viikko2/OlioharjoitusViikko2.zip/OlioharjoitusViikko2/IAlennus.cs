﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Testeri
{
    interface IAlennus
    {
        void LisäAlennus(float prosenttia);
        void MuutaAlennus(float alkuperäinen, float uusiAlennus);

    }
}
