﻿

public enum Verokanta
	{
	         Vapautus, 
             ALV_0 ,
             ALV_10 ,
             ALV_12,
             ALV_24,
}