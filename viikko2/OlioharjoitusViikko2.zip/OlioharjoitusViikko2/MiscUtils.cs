﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace OlioharjoitusViikko2
{
    class MiscUtils
    {
        public void DumpList(IEnumerable list)
        {
            var e = list.GetEnumerator();
            e.MoveNext();
            var o = e.Current;
            dumpPropertyNames(o);
            foreach (var item in list)
            {
                dumpObject(item);
            }
        }

        private void dumpPropertyNames(object o)
        {
            foreach (var pi in o.GetType().GetProperties())
            {
                Console.Write($"{pi.Name}\t");
            }
            Console.WriteLine();
        }

        private void dumpObject(object item)
        {
            foreach(var pi in item.GetType().GetProperties())
            {
                Console.Write($"{pi.GetValue(item)}\t");
            }
            Console.WriteLine();
        }
    }
}
