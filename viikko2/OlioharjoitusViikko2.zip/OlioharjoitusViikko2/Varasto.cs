﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OlioharjoitusViikko2
{
    class Varasto
    {
        public List<Tuote> Tuotteet { get; private set; }
        public string VarastonNimi { get; set; }

        private Dictionary<string, Tuote> luokitellut;

        public Varasto(string nimi)
        {
            VarastonNimi = nimi;
            Tuotteet = new List<Tuote>();
        }

        public void LisääTuote(Tuote t)
        {
            // toteutus: lisää t Tuotteet kokoelmaan Add-metodilla
            Tuotteet.Add(t);
        }

        public bool PoistaTuote(int tnro)
        {
            // etsi parametrin mukainen tuote ja poista se kokoelmasta vaikka RemoveAt-metodilla ja palauta true
            // jos ei löydy poistettavaa niin palauta false
            for (int i = 0; i < Tuotteet.Count; i++)
            {
                if (Tuotteet[i].Tuotenumero == tnro)
                {
                    Tuotteet.RemoveAt(i);
                    return true;
                }
            }
            return false;
        }

        public bool PoistaTuote(Tuote t)
        {
            // etsi parametrin mukainen tuote ja poista se kokoelmasta vaikka RemoveAt-metodilla tai vaikka Remove-metodilla
            // paluuarvo kuten toisessa PoistaTuote-metodissa
            return Tuotteet.Remove(t);
        }

        public decimal VarastonArvo()
        {
            decimal arvo = 0;
            foreach (var tuote in Tuotteet)
            {
                arvo += tuote.LaskeHinta();
            }
            return arvo; // Laske kaikkien tuotteiden hinta yhteen ja palauta se
        }


        public void PäivitäPerusluokitus()
        {
            //kalleimman ja halvimman tuotteen ja lisää ne Dictionaryyn avaimilla "Kallein" ja "Huokein"
            Tuote halvin = null, kallein = null;
            if (Tuotteet.Count == 0)
            {
                return;
            }
            kallein = halvin = Tuotteet[0];
            foreach (var t in Tuotteet)
            {
                if (kallein.Hinta < t.Hinta)
                {
                    kallein = t;
                }
                if (halvin.Hinta > t.Hinta)
                {
                    halvin = t;
                }
                if (luokitellut.ContainsKey("Kallein"))
                {
                    luokitellut["Kallein"] = kallein;
                }
                else
                {
                    luokitellut.Add("Kallein", kallein);
                }
                if (luokitellut.ContainsKey("Halvin"))
                {
                    luokitellut["Halvin"] = kallein;
                }
                else
                {
                    luokitellut.Add("Halvin", kallein);
                }
            }
        }
        public Tuote LuokiteltuTuote(string luokitus)
        {
            // palauttaa parametrina annetun 'luokituksen' mukaisen tuotteen ja jos ei löydy ko.tuotetta niin silloin palauttaa null-arvon
            if (!luokitellut.ContainsKey(luokitus))
            {
                return null;
            }
            return luokitellut[luokitus];
        }
    }

}
