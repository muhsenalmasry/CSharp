﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Testeri
{
    static class TuotenumeroGeneraattori
    {
        private static int tuotenumero = 1000;

        public static int SeuraavaTuotenumero
        {
            get
            {
                return tuotenumero++;
            }
        }
    }
}
