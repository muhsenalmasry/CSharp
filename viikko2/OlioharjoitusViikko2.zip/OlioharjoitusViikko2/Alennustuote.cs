﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OlioharjoitusViikko2
{
    class Alennustuote : Tuote
    {
        public float AlennusProsentti { get; set; }

        public Alennustuote()
        {
        }

        public Alennustuote(int tnumero, string tuotenimi, decimal hinta, float alennus)
            : base(tnumero, tuotenimi, hinta)
        {
            AlennusProsentti = alennus;
        }

        public override decimal LaskeHinta()
        {
            return base.LaskeHinta() - ((decimal)AlennusProsentti * base.LaskeHinta()) / 100M;
        }

    }
}
