﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OlioharjoitusViikko2
{
    class Tilaustuote : Tuote
    {
        private const decimal VakioTilausMaksu = 25M;

        private decimal _tilausKulut;

        public decimal TilausKulut {
            get { return _tilausKulut; }
            set {
                if (value < 0M)
                {
                    throw new ArgumentException("Tilauskulut pitää olla suurempi tai yhtäsuuri kuin nolla");
                }
                _tilausKulut = value;
            }
        }

        public Tilaustuote()
        {
            TilausKulut = VakioTilausMaksu;
        }
        public Tilaustuote(int tnumero, string tuotenimi, decimal hinta, decimal tilauskulut)
            : base(tnumero, tuotenimi, hinta)
        {
            TilausKulut = tilauskulut;
        }
        public override decimal LaskeHinta()
        {
            return base.LaskeHinta() + TilausKulut;
        }

        public override string ToString()
        {
            return $"{Tuotenumero}\t{Nimi,-20}\t{LaskeHinta()} josta toimitus/tilauskuluja {TilausKulut:C}";
        }
    }
}
