﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace OlioharjoitusViikko2
{
    class OmaTulostusVirta : StreamWriter
    {
        string _tiedostoNimi;
        public OmaTulostusVirta(string tiedosto): base(tiedosto)
        {
            _tiedostoNimi = tiedosto;
        }

        public void TalletaTuoteLista(List<Tuote> tuotteet)
        {
            // toteutus puuttuu toistaiseksi
        }

    }

    sealed class OmaMerkkijono : object
    {

    }


}
