﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OlioharjoitusViikko2
{
    class Tuote
    {
        public int Tuotenumero { get; set; }
        private string _nimi;
        private decimal _hinta;

        public Verokanta ALV { get; set; }

        public string Nimi
        {
            get { return _nimi; }
            set
            {
                if (value.Length >= 5)
                {
                    _nimi = value;
                }
                else
                {
                    throw new ArgumentException("Nimi pitää olla vähintään viisi merkkiä pitkä");
                }
            }
        }
        public decimal Hinta
        {
            get { return _hinta; }
            set
            {
                if (value > 0M)
                {
                    _hinta = value;
                }
                else
                {
                    throw new ArgumentException("Hinta pitää olla suurempi kuin nolla");
                }
            }
        }

        public Tuote() { }
        public Tuote(int tnro, string nimi, decimal hinta)
        {
            Tuotenumero = tnro;
            Nimi = nimi;
            Hinta = hinta;
        }

        public virtual decimal LaskeHinta()
        {
            decimal alvprosentti = 0;
            #region Ei ihan vielä
            //switch (ALV)
            //{
            //    case Verokanta.Vapautus:
            //        alvprosentti = 0;
            //        break;
            //    //case Verokanta.ALV_0:
            //    //break;
            //    case Verokanta.ALV_10:
            //        alvprosentti = 10;
            //        break;
            //    case Verokanta.ALV_12:
            //        alvprosentti = 12;
            //        break;
            //    case Verokanta.ALV_24:
            //        alvprosentti = 24;
            //        break;
            //    default:
            //        break;
            //}
            #endregion
            return Hinta + (Hinta * alvprosentti / 100M);
        }

        public override string ToString()
        {
            return $"{Tuotenumero}\t{Nimi,-20}\t{LaskeHinta()}";
        }

    }
}