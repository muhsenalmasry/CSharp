﻿using System;
using System.Collections.Generic;
using Testeri;

namespace OlioharjoitusViikko2
{
    class Program
    {
        static void Main(string[] args)
        {
            string nimi = "nimi";
            Tuote jj = new Tuote();
            jj.Tuotenumero = 1001; // TuotenumeroGeneraattori.SeuraavaTuotenumero;
            jj.Nimi = "Jatkojohto";  
            jj.Hinta = 100M;
            jj.ALV = Verokanta.ALV_10;
            Tuote hiiri = new Tuote(1020, "Hiiri", 9.99M);
            Tuote mukiteline = new Tuote() { Nimi = "Mukiteline", Tuotenumero = 3010, Hinta = 19.99M };

            // 1 Lisää nämä tuotteet Varastoon
            Varasto kv = new Varasto("Keskusvarasto");
            Varasto jemma = new Varasto("Sivukonttorin taustavarasto");

            kv.LisääTuote(jj);
            kv.LisääTuote(hiiri);
            kv.LisääTuote(mukiteline);

            Alennustuote halpa = new Alennustuote(12345, "Maski", 10M, 50F);
            kv.LisääTuote(halpa);

            decimal h = halpa.LaskeHinta();

            jemma.LisääTuote(hiiri);

            // 2 Tulosta kaikki tuotteet
            Console.WriteLine("tnro\tNimi\tHinta");
            foreach (var tuote in kv.Tuotteet)
            {
                Console.WriteLine(tuote);
            }

            // 3 Tulosta varaston arvo
            Console.WriteLine($"Varaston arvo on {kv.VarastonArvo()}");
            Console.WriteLine(kv.VarastonArvo());


            // 4 Testaa

            // 5 Poista Hiiri ja tulosta uudelleen tuotteet ja varaston arvo
            Console.WriteLine("Hiiren poisto:");
            kv.PoistaTuote(1020);

            Console.WriteLine("tnro\tNimi\tHinta");
            foreach (var tuote in kv.Tuotteet)
            {
                Console.WriteLine(tuote);
            }
            Console.WriteLine($"Varaston arvo on {kv.VarastonArvo()}");


            Alennustuote at1 = new Alennustuote() { AlennusProsentti = 50F } ;
            Alennustuote at2 = new Alennustuote(2345, "Tamagotchi", 100.0M, 80.0F);
 
            kv.LisääTuote(at2);

            Console.WriteLine("tnro\tNimi\tHinta");
            foreach (var tuote in kv.Tuotteet)
            {
                Console.WriteLine(tuote);
            }
            decimal summa = 0;
            foreach (Tuote item in kv.Tuotteet)
            {
                summa += item.LaskeHinta();
            }
            Console.WriteLine();
            Console.WriteLine(summa);
            Console.WriteLine(kv.VarastonArvo());


            Console.WriteLine();
            Console.WriteLine();
            MiscUtils mu = new MiscUtils();
            mu.DumpList(kv.Tuotteet);

        }
    }
}
